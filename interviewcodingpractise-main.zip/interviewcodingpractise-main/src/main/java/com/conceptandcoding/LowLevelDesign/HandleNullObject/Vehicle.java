package com.conceptandcoding.LowLevelDesign.HandleNullObject;

public interface Vehicle {

    int getTankCapacity();
    int getSeatingCapacity();
}
