package com.conceptandcoding.LowLevelDesign.DesignPatterns.FlyWeightPattern;

public class Sprites {
}
