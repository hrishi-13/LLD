package com.conceptandcoding.LowLevelDesign.DesignPatterns.AdapterDesignPattern.Adapter;

public interface WeightMachineAdapter {

    public double getWeightInKg();
}
