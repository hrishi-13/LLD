package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem;

public enum ReservationStatus {

    SCHEDULED,
    INPROGRESS,
    COMPLETED,
    CANCELLED;
}
