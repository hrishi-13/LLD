package com.conceptandcoding.LowLevelDesign.DesignBookMyShow.Enums;

public enum City {
    Bangalore,
    Delhi;
}
