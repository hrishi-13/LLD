package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem;

public enum ReservationType {

    HOURLY,
    DAILY;
}
