package com.conceptandcoding.LowLevelDesign.DesignSplitwise.Expense;

public enum ExpenseSplitType {
    EQUAL,
    UNEQUAL,
    PERCENTAGE;
}
