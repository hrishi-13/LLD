package com.conceptandcoding.LowLevelDesign.DesignOrderManagementSystem;

public interface PaymentMode {

    public boolean makePayment();
}
