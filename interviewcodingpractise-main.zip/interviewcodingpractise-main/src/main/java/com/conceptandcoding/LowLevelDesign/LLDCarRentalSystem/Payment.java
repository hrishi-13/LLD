package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem;

public class Payment {

    public void payBill(Bill bill) {
        //do payment processing and update the bill status;
    }
}
