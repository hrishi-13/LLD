package com.conceptandcoding.LowLevelDesign.LLDCarRentalSystem.Product;

public enum Status {

    ACTIVE,
    INACTIVE;
}
