package com.conceptandcoding.LowLevelDesign.DesignSplitwise.Expense.Split;

import java.util.List;

public class PercentageExpenseSplit implements ExpenseSplit {
    @Override
    public void validateSplitRequest(List<Split> splitList, double totalAmount) {

    }
}
